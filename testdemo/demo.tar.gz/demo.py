# coding:utf-8

print 'hello，我是同步上传'
